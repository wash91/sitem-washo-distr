
import React, { useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { PackageSearch, Truck, PackageCheck, PackageX, Package as PackageIcon } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";

const InventoryItem = ({ item, allProducts }) => {
  const productDetails = allProducts.find(p => p.id === item.productId);
  let icon;
  let colorClass = "text-gray-700";

  switch (productDetails?.category) {
    case 'Agua':
      icon = <PackageCheck className="h-6 w-6 mr-3 text-blue-500" />;
      colorClass = "text-blue-600";
      break;
    case 'BidonVacioConLlave':
    case 'BidonVacioSinLlave':
      icon = <PackageX className="h-6 w-6 mr-3 text-orange-500" />;
      colorClass = "text-orange-600";
      break;
    default:
      icon = <PackageIcon className="h-6 w-6 mr-3 text-gray-500" />;
      colorClass = "text-gray-700";
  }

  return (
    <div className="flex justify-between items-center p-4 bg-gray-50 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-200">
      <div className="flex items-center">
        {icon}
        <span className={`font-medium ${colorClass}`}>{item.productName || productDetails?.name || 'Producto Desconocido'}</span>
      </div>
      <span className={`font-bold text-lg ${colorClass}`}>{item.quantity} unidades</span>
    </div>
  );
};


const TruckInventoryPage = () => {
  const { getTruckInventoryForDistributor, products: allProducts, cashOpenings, trucks, isDataLoaded, reloadAllData } = useData();
  const { user } = useAuth();

  useEffect(() => {
    if (isDataLoaded) {
      reloadAllData(); 
    }
  }, [isDataLoaded, reloadAllData]);

  const currentTruckInventory = useMemo(() => {
    if (user?.id && isDataLoaded) {
      return getTruckInventoryForDistributor(user.id);
    }
    return [];
  }, [getTruckInventoryForDistributor, user?.id, cashOpenings, isDataLoaded]); 

  const activeOpening = useMemo(() => {
    if (!isDataLoaded) return null;
    return cashOpenings.find(op => op.distributorId === user?.id && !op.isClosed);
  }, [cashOpenings, user?.id, isDataLoaded]);

  const assignedTruck = useMemo(() => {
    if (!isDataLoaded || !activeOpening || !activeOpening.truckId) return null;
    return trucks.find(t => t.id === activeOpening.truckId);
  }, [activeOpening, trucks, isDataLoaded]);

  const { filledContainers, emptyContainers, accessories } = useMemo(() => {
    const categorized = { filledContainers: [], emptyContainers: [], accessories: [] };
    currentTruckInventory.forEach(item => {
      const productDetails = allProducts.find(p => p.id === item.productId);
      if (productDetails?.category === 'Agua') {
        categorized.filledContainers.push(item);
      } else if (productDetails?.category.startsWith('BidonVacio')) {
        categorized.emptyContainers.push(item);
      } else {
        categorized.accessories.push(item);
      }
    });
    return categorized;
  }, [currentTruckInventory, allProducts]);

  if (!isDataLoaded) {
    return (
        <div className="flex justify-center items-center h-screen">
            <p>Cargando inventario...</p>
        </div>
    );
  }

  if (!activeOpening) {
    return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto p-4 flex flex-col items-center justify-center h-full"
      >
        <PackageSearch className="h-16 w-16 text-gray-400 mb-4" />
        <h1 className="text-2xl font-bold text-gray-700 mb-2">Inventario de Camión</h1>
        <p className="text-gray-500 text-center">No hay una apertura de caja activa. Por favor, registre una apertura para ver el inventario del camión.</p>
      </motion.div>
    );
  }
  
  if (!assignedTruck) {
     return (
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="container mx-auto p-4 flex flex-col items-center justify-center h-full"
      >
        <Truck className="h-16 w-16 text-gray-400 mb-4" />
        <h1 className="text-2xl font-bold text-gray-700 mb-2">Inventario de Camión</h1>
        <p className="text-gray-500 text-center">No hay un camión asignado a la apertura de caja actual.</p>
      </motion.div>
    );
  }


  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="container mx-auto p-4"
    >
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold text-gray-800 flex items-center">
            <Truck className="mr-3 h-8 w-8 text-indigo-600" />Inventario del Camión: {assignedTruck.plate}
        </h1>
      </div>
      
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center"><PackageCheck className="mr-2 h-6 w-6 text-blue-500" /> Bidones Llenos (Agua)</CardTitle>
          <CardDescription>Productos listos para la venta.</CardDescription>
        </CardHeader>
        <CardContent>
          {filledContainers.length > 0 ? (
            <div className="space-y-3">
              {filledContainers.map(item => <InventoryItem key={item.productId} item={item} allProducts={allProducts} />)}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-4">No hay bidones llenos en el camión.</p>
          )}
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center"><PackageX className="mr-2 h-6 w-6 text-orange-500" /> Bidones Vacíos</CardTitle>
          <CardDescription>Envases retornados o disponibles.</CardDescription>
        </CardHeader>
        <CardContent>
          {emptyContainers.length > 0 ? (
            <div className="space-y-3">
              {emptyContainers.map(item => <InventoryItem key={item.productId} item={item} allProducts={allProducts} />)}
            </div>
          ) : (
            <p className="text-center text-gray-500 py-4">No hay bidones vacíos registrados en el camión.</p>
          )}
        </CardContent>
      </Card>

      {accessories.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center"><PackageIcon className="mr-2 h-6 w-6 text-gray-500" /> Accesorios y Otros</CardTitle>
            <CardDescription>Otros productos en inventario.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {accessories.map(item => <InventoryItem key={item.productId} item={item} allProducts={allProducts} />)}
            </div>
          </CardContent>
        </Card>
      )}

      {currentTruckInventory.length === 0 && filledContainers.length === 0 && emptyContainers.length === 0 && accessories.length === 0 && (
         <p className="text-center text-gray-500 py-8 text-lg">El inventario del camión está completamente vacío.</p>
      )}

    </motion.div>
  );
};

export default TruckInventoryPage;
